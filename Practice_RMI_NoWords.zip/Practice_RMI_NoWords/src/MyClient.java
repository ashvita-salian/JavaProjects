import java.rmi.Naming;
import java.util.Scanner;

public class MyClient {
	public static void main(String args[]) {
		try {
			NoToWordsInterface stub = (NoToWordsInterface) Naming.lookup("rmi://localhost:5000/ashvita");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Number: ");
			char[] a = sc.next().toCharArray();
			//System.out.println("Number in words: ");
			stub.numberToWords(a);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
