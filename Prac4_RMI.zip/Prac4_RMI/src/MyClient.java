import java.rmi.*;

public class MyClient {
	public static void main(String args[]) {
		try {
			DateTime stub = (DateTime) Naming.lookup("rmi://localhost:5000/ashvita");
			System.out.println("Current Date: " + stub.date(1) + "\n" + "Current Time:" + stub.date(2));
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
