import java.rmi.Naming;
import java.util.Scanner;

public class MyClient {
	public static void main(String args[]) {
		try {
			Scanner sc = new Scanner(System.in);
			Factorial stub = (Factorial) Naming.lookup("rmi://localhost:5000/factorial");
			System.out.println("Enter number: ");
			int num = sc.nextInt();
			System.out.println("Factorial: " + stub.factorial(num));
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
