import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Factorial extends Remote {
	public int factorial(int num) throws RemoteException;
}
