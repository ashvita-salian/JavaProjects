import java.rmi.*;
import java.rmi.registry.*;

public class MyServer {
	public static void main(String args[]) {
		try {
			Factorial stub = new FactorialRemote();
			Naming.rebind("rmi://localhost:5000/factorial", stub);
			System.out.println("Server Started");
		} catch (Exception e) {
			System.out.print("exception on server");
			System.out.println(e);
		}
	}
}
