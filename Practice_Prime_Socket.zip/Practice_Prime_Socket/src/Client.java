import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Client {
	public static void main(String[] args) {
		try {
			InetAddress ia = InetAddress.getLocalHost();
			DatagramSocket ds = new DatagramSocket();
			byte b1[] = new byte[50];
			DatagramSocket ds1 = new DatagramSocket(1300);
			System.out.println("\nClient Started\n");
			while (true) {
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.println("\nEnter number\n");
				String str = br.readLine();
				byte b[] = str.getBytes();
				DatagramPacket dp = new DatagramPacket(b, b.length, ia, 1200);
				ds.send(dp);
				dp = new DatagramPacket(b1, b1.length);
				ds1.receive(dp);
				String s = new String(dp.getData(), 0, dp.getLength());
				System.out.println("\n" + s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
