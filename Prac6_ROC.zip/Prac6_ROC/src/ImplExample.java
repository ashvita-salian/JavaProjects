import java.sql.*;
import java.util.*;

public class ImplExample implements BooksInterface {
	public List<Book> getAllBooks() throws Exception {
		List<Book> list = new ArrayList<Book>();
		String DB_URL = "jdbc:mysql://localhost/bookdb";
		Connection conn = null;
		Statement stmt = null;
		System.out.println("Connecting to a selected database...");
		conn = DriverManager.getConnection(DB_URL, "root", "");
		System.out.println("Connected database successfully...");
		System.out.println("Creating statement...");
		stmt = conn.createStatement();
		String sql = "SELECT * FROM book";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			int id = rs.getInt("Book_id");
			String name = rs.getString("Book_name");
			String author = rs.getString("Book_author");
			Book book = new Book();
			book.setBook_id(id);
			book.setBook_name(name);
			book.setBook_author(author);
			list.add(book);
		}
		rs.close();
		return list;
	}
	public Book getBookById(int id) throws Exception {
		Book book = null;
		String DB_URL = "jdbc:mysql://localhost/bookdb";
		Connection conn = null;
		System.out.println("Connecting to a selected database...");
		conn = DriverManager.getConnection(DB_URL, "root", "");
		System.out.println("Connected database successfully...");
		System.out.println("Creating statement...");
		String query = "Select * from Book where Book_id=?";
		PreparedStatement myStmt = conn.prepareStatement(query);
		myStmt.setInt(1, id);
		ResultSet rs = myStmt.executeQuery();
		while (rs.next()) {
			int id1 = rs.getInt("Book_id");
			String name = rs.getString("Book_name");
			String author = rs.getString("Book_author");
			book = new Book();
			book.setBook_id(id1);
			book.setBook_name(name);
			book.setBook_author(author);
		}
		rs.close();
		return book;
	}
}