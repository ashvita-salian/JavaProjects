import java.rmi.Remote;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmployeeData implements EmpInterface  {
	public Employee getContactByEmpId(int id) throws Exception {
		Employee emp = null;
		String DB_URL = "jdbc:mysql://localhost/empdb";
		Connection conn = null;
		System.out.println("Connecting to a selected database...");
		conn = DriverManager.getConnection(DB_URL, "root", "");
		System.out.println("Connected database successfully...");
		System.out.println("Creating statement...");
		String query = "Select * from emp where emp_id=?";
		PreparedStatement myStmt = conn.prepareStatement(query);
		myStmt.setInt(1, id);
		ResultSet rs = myStmt.executeQuery();
		while (rs.next()) {
			int id1 = rs.getInt("emp_id");
			String contact = rs.getString("emp_contact");
			emp = new Employee();
			emp.setId(id1);
			emp.setContact(contact);		}
		System.out.println("Query Completed!");
		rs.close();
		return emp;
	}
}
