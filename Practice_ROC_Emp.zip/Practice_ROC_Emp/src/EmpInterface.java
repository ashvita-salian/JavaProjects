import java.rmi.Remote;

public interface EmpInterface extends Remote{
	public Employee getContactByEmpId(int id) throws Exception;
}
