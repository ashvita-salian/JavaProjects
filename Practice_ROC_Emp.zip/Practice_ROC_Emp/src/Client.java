import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.Scanner;
import java.io.Serializable;

public class Client {
	Client() {
	}

	public static void main(String[] args) throws Exception {
		try {
			Registry registry = LocateRegistry.getRegistry(null);
			EmpInterface stub = (EmpInterface) registry.lookup("Employee");
			Scanner sc = new Scanner(System.in);
			System.out.print("Get Contact By Emp Id ");
			System.out.print("Enter emp id: ");
			int id = sc.nextInt();
			Employee emp = (Employee) stub.getContactByEmpId(id);
			System.out.println("ID: " + emp.getId() + "\nContact: " + emp.getContact());
		} catch (Exception e) {
			System.err.println("Client exception: " + e.toString());
			e.printStackTrace();
		}
	}
}
