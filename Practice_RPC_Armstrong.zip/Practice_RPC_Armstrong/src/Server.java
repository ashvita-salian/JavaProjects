import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.time.Year;
import java.util.StringTokenizer;

class Server {
	public static String Armstrong(int number) {
		String res;
		int originalNumber, remainder, result = 0;
		originalNumber = number;
		while (originalNumber != 0) {
			remainder = originalNumber % 10;
			result += Math.pow(remainder, 3);
			originalNumber /= 10;
		}
		if (result == number)
			res = number + " is an Armstrong number.";
		else
			res = number + " is not an Armstrong number.";
		return res;
	}
	public static String OddEven(int number) {
		String res;
		if(number % 2 == 0)
			res = number + " is an even number.";
		else
			res = number + " is an odd number.";
		return res;
	}
	public static String age(int year) {
		String res;
		int current = Year.now().getValue();
		int age = current-year;
		res = "Age is : "+age;
		return res;
	}

	public static void main(String[] args) throws IOException {
		DatagramSocket ds = new DatagramSocket(1234);
		byte[] buf = null;
		DatagramPacket DpReceive = null;
		DatagramPacket DpSend = null;
		System.out.println("Server Started");
		while (true) {
			buf = new byte[65535];
			DpReceive = new DatagramPacket(buf, buf.length);
			ds.receive(DpReceive);
			String inp = new String(buf, 0, buf.length);
			inp = inp.trim();
			System.out.println("Number Received:- " + inp);
			if (inp.equals("close")) {
				System.out.println("Client sent closing");
				break;
			}

			String res;
			StringTokenizer st = new StringTokenizer(inp);
			int number = Integer.parseInt(st.nextToken());
			res = Armstrong(number);
			//res = OddEven(number);
			//res = age(number);
			System.out.println("Sending the result...");
			buf = res.getBytes();
			int port = DpReceive.getPort();
			DpSend = new DatagramPacket(buf, buf.length, InetAddress.getLocalHost(), port);
			ds.send(DpSend);
		}
	}
}