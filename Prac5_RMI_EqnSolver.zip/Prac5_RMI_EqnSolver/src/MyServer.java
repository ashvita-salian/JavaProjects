import java.rmi.*;
import java.rmi.registry.*;

public class MyServer {
	public static void main(String args[]) {
		try {
			System.out.println("Server started, waiting for client to enter equation");
			EquationSolverInterface stub = new EquationSolverClass();
			Naming.rebind("EquationSolver", stub);
		} catch (Exception e) {
			System.out.println("exception on server");
			System.out.println(e);
		}
	}
}