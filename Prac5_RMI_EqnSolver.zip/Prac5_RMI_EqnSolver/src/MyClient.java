import java.rmi.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class MyClient {
	public static void main(String args[]) {
		while (true) {
			try {
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter equation: ");
				String equation = sc.nextLine();
				Set<String> tree = new TreeSet<>();
				ArrayList<Integer> params = new ArrayList<Integer>();
				for (char c : equation.toCharArray()) {
					if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
						tree.add(Character.toString(c));
					}
				}
				int n = tree.size();
				Iterator value = tree.iterator();
				while (value.hasNext()) {
					System.out.println("Enter value for " + value.next());
					int temp = sc.nextInt();
					params.add(temp);
				}
				EquationSolverInterface stub = (EquationSolverInterface) Naming.lookup("EquationSolver");
				System.out.println("Answer: " + stub.EvaluateEquation(equation, params));
			}

			catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}