import java.io.IOException;
import java.util.Arrays;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "HelloAppEngine", urlPatterns = { "/hello" })
public class HelloAppEngine extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		int arr[] = { 16, 21, 32, 48, 56 };
		int key = 30;
		response.getWriter().print("Array : ");
		for (int i = 0; i < 5; i++) {
			response.getWriter().print(" " + arr[i]);
		}
		response.getWriter().println("\n\nSearch for element: " + key + "\n");
		int last = arr.length - 1;
		int first = 0;
		int mid = (first + last) / 2;
		while (first <= last) {
			if (arr[mid] < key) {
				first = mid + 1;
			} else if (arr[mid] == key) {
				response.getWriter().print("Element is found at index:" + mid + "\n");
				break;
			} else {
				last = mid - 1;
			}
			mid = (first + last) / 2;
		}
		if (first > last) {
			response.getWriter().print("Element is not found!");
		}
	}
}