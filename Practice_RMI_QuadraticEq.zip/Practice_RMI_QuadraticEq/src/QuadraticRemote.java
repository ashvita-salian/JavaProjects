import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class QuadraticRemote extends UnicastRemoteObject implements Quadratic {
	public QuadraticRemote() throws RemoteException {
	}

	public String Eq(int a, int b, int c) throws RemoteException {
		if ((b * b - 4 * a * c) < 0) {
			return "x = Irrational number.";
		} else {
			double d = (-b + Math.sqrt(b * b - 4 * a * c)) / (2 * a);
			double e = (-b - Math.sqrt(b * b - 4 * a * c)) / (2 * a);
			return "x = " + d + " or x = " + e;
		}
	}
}
