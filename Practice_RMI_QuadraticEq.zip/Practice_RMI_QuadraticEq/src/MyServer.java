import java.rmi.Naming;

public class MyServer {
	public static void main(String args[]) {
		try {
			QuadraticRemote esi = new QuadraticRemote();
			Naming.rebind("EquationServer", esi);
			System.out.println("The server is started.");
		} catch (Exception e) {
		}
	}
}
