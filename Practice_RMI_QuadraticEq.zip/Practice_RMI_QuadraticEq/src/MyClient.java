import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.Naming;

public class MyClient {
	public static void main(String args[]) {
		try {
			String equrl = "rmi://localhost/EquationServer";
			Quadratic eqin = (Quadratic) Naming.lookup(equrl);
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int a, b, c;
			System.out.print("\nEnter the value of a: ");
			a = Integer.parseInt(br.readLine());
			System.out.print("\nEnter the value of b: ");
			b = Integer.parseInt(br.readLine());
			System.out.print("\nEnter the value of c: ");
			c = Integer.parseInt(br.readLine());
			System.out.println("\n\nAnswer: " + eqin.Eq(a, b, c));
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
	}
}
