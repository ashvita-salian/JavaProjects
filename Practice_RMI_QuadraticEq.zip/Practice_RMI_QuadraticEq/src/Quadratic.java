import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Quadratic extends Remote {
	String Eq(int a, int b, int c) throws RemoteException;
}
