import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SumOfNumbers", urlPatterns = { "/sumofnumbers" })
public class HelloAppEngine extends HttpServlet {

	@Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) 
      throws IOException {

    response.setContentType("text/plain");
    response.setCharacterEncoding("UTF-8");

    //response.getWriter().print("Hello App Engine!\r\n");
    String num = request.getParameter("number");
    String[] splitArray = num.split(",");
    int arr[] = new int[splitArray.length];
    for (int i = 0; i < splitArray.length; i++) {
        arr[i] = Integer.parseInt(splitArray[i]);
    }
    /*//Sum of all numbers in array
    PrintWriter out = response.getWriter();
    
    response.getWriter().print("Array : ");
    for (int i = 0; i <arr.length; i++) {
    response.getWriter().print(" " + arr[i]);}
    int sum=0;
    int i;
    response.getWriter().println(" ");
    for (i = 0; i < arr.length; i++)
    sum += arr[i];
    response.getWriter().println("Sum of given array is : " + sum);*/
    
    for(int i=0; i<arr.length; i++){
        boolean isPrime = true;
        for (int j=2; j<arr[i]; j++){
            if(arr[i]%j==0){
                isPrime = false;
                break;
            }
        }
        if(isPrime)
        	response.getWriter().println(arr[i] + " are the prime numbers in the array ");
            //System.out.println(i + " are the prime numbers in the array ");
    }
    }
}