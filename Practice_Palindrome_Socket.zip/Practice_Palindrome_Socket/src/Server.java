import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Server {
	public static boolean isPalindrome(int n) {
		int r, sum = 0, temp;
		temp = n;
		while (n > 0) {
			r = n % 10;
			sum = (sum * 10) + r;
			n = n / 10;
		}
		if (temp == sum) {
			return true;
		} else {
			return false;
		}
	}
	public static void main(String[] args) {
		DatagramSocket ds;
		DatagramPacket dp;
		String str;
		try {
			ds = new DatagramSocket(1200);
			byte b[] = new byte[4096];
			System.out.println("Server Started : ");
			while (true) {
				dp = new DatagramPacket(b, b.length);
				ds.receive(dp);
				str = new String(dp.getData(), 0, dp.getLength());
				int n = Integer.parseInt(str);
				StringBuilder singleString = new StringBuilder();
				if (isPalindrome(n)) {
					singleString.append(n + " is a palindrome");
				} else {
					singleString.append(n + " is not a palindrome");
				}
				InetAddress ia = InetAddress.getLocalHost();
				byte b1[] = singleString.toString().getBytes();
				DatagramSocket ds1 = new DatagramSocket();
				DatagramPacket dp1 = new DatagramPacket(b1, b1.length, InetAddress.getLocalHost(), 1300);
				System.out.println("result : " + singleString + "\n");
				ds1.send(dp1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}